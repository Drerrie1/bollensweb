/* ============================================================
   Groep Fibover — Shared Components
   Nav, Footer, Mobile Menu, Scroll Animations
   ============================================================ */

(function () {
  const body = document.body;
  const page = body.dataset.page || 'home';
  const base = body.dataset.basepath || '';

  /* ---- Navigation ---- */
  function renderNav() {
    const navLinks = [
      { id: 'home', label: 'Home', href: `${base}index.html` },
      { id: 'over-ons', label: 'Over ons', href: `${base}over-ons.html` },
      { id: 'diensten', label: 'Diensten', href: `${base}diensten.html` },
      { id: 'contact', label: 'Contact', href: `${base}contact.html` },
      { id: 'dashboard', label: 'Dashboard', href: `${base}dashboard.html` },
    ];

    const linkHTML = navLinks
      .map(
        (l) => `
      <a href="${l.href}"
         class="nav-link relative px-1 py-2 text-sm font-medium transition-colors duration-200
                ${page === l.id ? 'text-brand-700' : 'text-text-secondary hover:text-brand-700'}
                focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-400 focus-visible:ring-offset-2 rounded"
         ${page === l.id ? 'aria-current="page"' : ''}>
        ${l.label}
        ${page === l.id ? '<span class="absolute bottom-0 left-0 right-0 h-0.5 bg-brand-700 rounded-full"></span>' : ''}
      </a>`
      )
      .join('');

    const mobileLinksHTML = navLinks
      .map(
        (l) => `
      <a href="${l.href}"
         class="block px-4 py-3 text-base font-medium rounded-lg transition-colors duration-200
                ${page === l.id ? 'text-brand-700 bg-brand-50' : 'text-text-primary hover:text-brand-700 hover:bg-surface-muted'}
                focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-400"
         ${page === l.id ? 'aria-current="page"' : ''}>
        ${l.label}
      </a>`
      )
      .join('');

    const el = document.getElementById('nav-placeholder');
    if (!el) return;

    el.innerHTML = `
    <a href="#main-content" class="sr-only focus:not-sr-only focus:absolute focus:top-4 focus:left-4 focus:z-[100] focus:bg-white focus:text-brand-700 focus:px-4 focus:py-2 focus:rounded-lg focus:shadow-lg font-medium text-sm">
      Ga naar inhoud
    </a>
    <nav class="fixed top-0 left-0 right-0 z-50 bg-white/90 backdrop-blur-md border-b border-surface-border" aria-label="Hoofdnavigatie">
      <div class="max-w-6xl mx-auto px-5 md:px-8 flex items-center justify-between h-20 md:h-24">
        <!-- Logo -->
        <a href="${base}index.html" class="flex-shrink-0 flex items-center gap-4 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-400 focus-visible:ring-offset-2 rounded py-2 group">
          <svg width="52" height="52" viewBox="0 0 44 44" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" class="flex-shrink-0">
            <!-- Growth bars -->
            <rect x="2" y="26" width="6" height="14" rx="1.5" fill="#b0aaaa"/>
            <rect x="11" y="18" width="6" height="22" rx="1.5" fill="#c75b5b"/>
            <rect x="20" y="10" width="6" height="30" rx="1.5" fill="#8b2332"/>
            <!-- F letter -->
            <rect x="30" y="4" width="6" height="36" rx="1.5" fill="#8b2332"/>
            <rect x="30" y="4" width="14" height="5" rx="1.5" fill="#c75b5b"/>
            <rect x="30" y="17" width="10" height="4.5" rx="1.5" fill="#c75b5b"/>
          </svg>
          <div class="flex flex-col leading-tight">
            <span class="text-2xl md:text-[1.7rem] font-bold tracking-tight text-text-primary" style="font-family:'DM Sans',sans-serif;letter-spacing:-0.02em;"><span style="color:#2c2525;">Groep</span><span style="color:#8b2332;">Fibover</span></span>
            <span class="text-[10.5px] md:text-xs tracking-[0.15em] uppercase text-text-tertiary font-medium">Accountants & Adviseurs</span>
          </div>
        </a>

        <!-- Desktop links -->
        <div class="hidden md:flex items-center gap-8">
          ${linkHTML}
        </div>

        <!-- Desktop CTA -->
        <a href="${base}contact.html"
           class="hidden md:inline-flex items-center px-5 py-2.5 text-sm font-medium text-white bg-brand-700 rounded-lg
                  hover:bg-brand-800 active:scale-[0.97]
                  focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-400 focus-visible:ring-offset-2
                  transition-transform duration-200"
           style="transition: transform 0.25s cubic-bezier(0.34,1.56,0.64,1), background-color 0.2s ease;">
          Neem contact op
        </a>

        <!-- Mobile hamburger -->
        <button id="mobile-menu-btn" type="button"
                class="md:hidden flex items-center justify-center w-10 h-10 rounded-lg text-text-secondary
                       hover:text-brand-700 hover:bg-surface-muted
                       focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-400
                       transition-colors duration-200"
                aria-expanded="false" aria-controls="mobile-menu" aria-label="Menu openen">
          <svg id="hamburger-icon" class="w-6 h-6" fill="none" stroke="currentColor" stroke-width="1.8" viewBox="0 0 24 24" aria-hidden="true">
            <path stroke-linecap="round" stroke-linejoin="round" d="M4 6h16M4 12h16M4 18h16"/>
          </svg>
          <svg id="close-icon" class="w-6 h-6 hidden" fill="none" stroke="currentColor" stroke-width="1.8" viewBox="0 0 24 24" aria-hidden="true">
            <path stroke-linecap="round" stroke-linejoin="round" d="M6 18L18 6M6 6l12 12"/>
          </svg>
        </button>
      </div>

      <!-- Mobile menu panel -->
      <div id="mobile-menu" class="md:hidden overflow-hidden transition-[max-height] duration-300 ease-out max-h-0" aria-hidden="true">
        <div class="px-5 pb-5 pt-2 space-y-1 border-t border-surface-border bg-white">
          ${mobileLinksHTML}
          <a href="${base}contact.html"
             class="block mt-3 text-center px-5 py-3 text-sm font-medium text-white bg-brand-700 rounded-lg
                    hover:bg-brand-800 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-400
                    transition-colors duration-200">
            Neem contact op
          </a>
        </div>
      </div>
    </nav>
    <!-- Spacer for fixed nav -->
    <div class="h-20 md:h-24"></div>`;
  }

  /* ---- Footer ---- */
  function renderFooter() {
    const el = document.getElementById('footer-placeholder');
    if (!el) return;

    el.innerHTML = `
    <footer class="bg-surface-muted border-t border-surface-border">
      <div class="max-w-6xl mx-auto px-5 md:px-8 py-16 md:py-20">
        <div class="grid grid-cols-1 md:grid-cols-4 gap-12 md:gap-8 items-start">
          <!-- Col 1: Logo only -->
          <div class="md:col-span-1 flex items-start">
            <a href="${base}index.html" class="inline-flex items-center gap-3 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-400 rounded">
              <svg width="40" height="40" viewBox="0 0 44 44" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" class="flex-shrink-0">
                <rect x="2" y="26" width="6" height="14" rx="1.5" fill="#b0aaaa"/>
                <rect x="11" y="18" width="6" height="22" rx="1.5" fill="#c75b5b"/>
                <rect x="20" y="10" width="6" height="30" rx="1.5" fill="#8b2332"/>
                <rect x="30" y="4" width="6" height="36" rx="1.5" fill="#8b2332"/>
                <rect x="30" y="4" width="14" height="5" rx="1.5" fill="#c75b5b"/>
                <rect x="30" y="17" width="10" height="4.5" rx="1.5" fill="#c75b5b"/>
              </svg>
              <div class="flex flex-col leading-tight">
                <span class="text-lg font-bold tracking-tight" style="font-family:'DM Sans',sans-serif;letter-spacing:-0.02em;"><span style="color:#2c2525;">Groep</span><span style="color:#8b2332;">Fibover</span></span>
                <span class="text-[9px] tracking-[0.15em] uppercase text-text-tertiary font-medium">Accountants & Adviseurs</span>
              </div>
            </a>
          </div>

          <!-- Col 2: Quick links -->
          <div>
            <h3 class="font-display text-text-primary text-lg mb-4">Navigatie</h3>
            <ul class="space-y-2.5">
              <li><a href="${base}index.html" class="text-sm text-text-secondary hover:text-brand-700 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-400 rounded transition-colors duration-200">Home</a></li>
              <li><a href="${base}over-ons.html" class="text-sm text-text-secondary hover:text-brand-700 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-400 rounded transition-colors duration-200">Over ons</a></li>
              <li><a href="${base}diensten.html" class="text-sm text-text-secondary hover:text-brand-700 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-400 rounded transition-colors duration-200">Diensten</a></li>
              <li><a href="${base}contact.html" class="text-sm text-text-secondary hover:text-brand-700 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-400 rounded transition-colors duration-200">Contact</a></li>
            </ul>
          </div>

          <!-- Col 3: Contact info -->
          <div>
            <h3 class="font-display text-text-primary text-lg mb-4">Contact</h3>
            <address class="not-italic space-y-2.5 text-sm text-text-secondary">
              <p>Witvenstraat 84-86<br>2940 Stabroek</p>
              <p><a href="tel:+3235413311" class="hover:text-brand-700 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-400 rounded transition-colors duration-200">+32 (3) 541.33.11</a></p>
              <p><a href="mailto:filip@groepfibover.be" class="hover:text-brand-700 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-400 rounded transition-colors duration-200">filip@groepfibover.be</a></p>
              <p><a href="mailto:joris@groepfibover.be" class="hover:text-brand-700 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-400 rounded transition-colors duration-200">joris@groepfibover.be</a></p>
            </address>
          </div>

          <!-- Col 4: Bedrijfsgegevens -->
          <div>
            <h3 class="font-display text-text-primary text-lg mb-4">Gegevens</h3>
            <div class="space-y-2.5 text-sm text-text-secondary">
              <p>BTW: BE 0885.524.381</p>
              <p>ITAA: 50.492.439</p>
            </div>
          </div>
        </div>
      </div>

      <!-- Bottom bar -->
      <div class="border-t border-surface-border">
        <div class="max-w-6xl mx-auto px-5 md:px-8 py-5 text-center text-xs text-text-tertiary">
          <p>&copy; 2007–2026 Groep Fibover. Alle rechten voorbehouden.</p>
        </div>
      </div>
    </footer>`;
  }

  /* ---- Mobile Menu Toggle ---- */
  function initMobileMenu() {
    const btn = document.getElementById('mobile-menu-btn');
    const menu = document.getElementById('mobile-menu');
    const hamburger = document.getElementById('hamburger-icon');
    const closeIcon = document.getElementById('close-icon');
    if (!btn || !menu) return;

    let isOpen = false;

    btn.addEventListener('click', () => {
      isOpen = !isOpen;
      btn.setAttribute('aria-expanded', String(isOpen));
      btn.setAttribute('aria-label', isOpen ? 'Menu sluiten' : 'Menu openen');
      menu.setAttribute('aria-hidden', String(!isOpen));

      if (isOpen) {
        menu.style.maxHeight = menu.scrollHeight + 'px';
      } else {
        menu.style.maxHeight = '0';
      }

      hamburger.classList.toggle('hidden', isOpen);
      closeIcon.classList.toggle('hidden', !isOpen);
    });
  }

  /* ---- Scroll Fade-in Animations ---- */
  function initScrollAnimations() {
    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
      document.querySelectorAll('.fade-section').forEach((el) => el.classList.add('visible'));
      return;
    }

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((e) => {
          if (e.isIntersecting) {
            e.target.classList.add('visible');
            observer.unobserve(e.target);
          }
        });
      },
      { threshold: 0.1, rootMargin: '0px 0px -40px 0px' }
    );

    document.querySelectorAll('.fade-section').forEach((el) => observer.observe(el));
  }

  /* ---- Nav shadow on scroll ---- */
  function initNavScroll() {
    const nav = document.querySelector('nav');
    if (!nav) return;

    let ticking = false;
    window.addEventListener('scroll', () => {
      if (!ticking) {
        window.requestAnimationFrame(() => {
          if (window.scrollY > 10) {
            nav.style.boxShadow = '0 1px 0 rgba(232,229,224,0.8), 0 4px 12px rgba(44,37,37,0.05)';
          } else {
            nav.style.boxShadow = 'none';
          }
          ticking = false;
        });
        ticking = true;
      }
    });
  }

  /* ---- Init ---- */
  document.addEventListener('DOMContentLoaded', () => {
    renderNav();
    renderFooter();
    initMobileMenu();
    initScrollAnimations();
    initNavScroll();
  });
})();
